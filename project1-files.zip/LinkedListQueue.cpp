//LinkedListQueue.cpp
#ifndef _LINKEDLISTQUEUE_CPP
#define _LINKEDLISTQUEUE_CPP

#include "LinkedListQueue.hpp"
#include <cstdlib> //for NULL
#include <cassert>
#include <iostream>
LinkedListQueue::LinkedListQueue()
{
  // TODO:  Initialize any member variables as needed in the constructor.
}

void LinkedListQueue::add(MazeState *elem)
{
  // TODO:  Implement this.
}

MazeState *LinkedListQueue::remove()
{
  // TODO:  Implement this.
}

bool LinkedListQueue::is_empty()
{
  // TODO:  Implement this.
}

LinkedListQueue::~LinkedListQueue()
{
  // TODO:  Implement the destructor.  Be sure to delete everything.
}

#endif

